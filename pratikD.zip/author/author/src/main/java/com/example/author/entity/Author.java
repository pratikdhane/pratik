package com.example.author.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import java.util.ArrayList;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="author_info")

public class Author {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	int id;
	String country;
	String name;
	@JsonBackReference
	@OneToMany(mappedBy="author",cascade=CascadeType.ALL,orphanRemoval=true)
	List<Books> bk=new ArrayList<Books>();
	
	public Author() {
		super();
	}
	public Author(int id, String country, String name) {
		super();
		this.id = id;
		this.country = country;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public String getCountry() {
		return country;
	}
	public String getName() {
		return name;
	}
	public List<Books> getBk() {
		return bk;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setBk(List<Books> bk) {
		this.bk = bk;
	}
	
	
	
	

}
