package com.example.author.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.author.entity.Author;
import com.example.author.entity.Books;
import com.example.author.repository.AuthorRepo;
import com.example.author.repository.BooksRepo;



@Service
public class MyService {
	@Autowired
	AuthorRepo ar;
	@Autowired
	BooksRepo br;
	public String saveTrainer(Author a)
	{
		for( Books bk: a.getBk() )
		{
			bk.setAuthor(a);
		}
		ar.save(a);
		return "record added successfully";
	}
	public List<Author>findAll()
	{
		return ar.findAll();
	}
	public Author findById(int id)
	{
		return ar.findById(id).orElse(null);
	}
	public String deleteById(int id)

	{
		ar.deleteById(id);
		return "record deleted successfully";
	}
	public String update(int id , Author a)
	{
		Author exa=ar.findById(id).orElse(null);
		if(a!=null)
		{
			if(a.getName()!=null)
			{
				exa.setName(a.getName());
			}
			if(a.getCountry()!=null)
			{
				exa.setCountry(a.getCountry());
			}
			List<Books> bList=a.getBk();
			for(Books b:bList)
			{
				if(b.getId()!=0)
				{
					Books ebk=br.findById(b.getId()).orElse(null);
					ebk.setpYear(b.getpYear());
					ebk.setTitle(b.getTitle());
					
				}
				else {
					b.setAuthor(a);
					exa.getBk().add(b);
				}
			}
			ar.save(exa);
				
		}
		return "Updated Successfully";
	}

}
