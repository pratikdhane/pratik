package com.example.author.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.author.entity.Books;

public interface BooksRepo extends JpaRepository<Books, Integer> {

}
