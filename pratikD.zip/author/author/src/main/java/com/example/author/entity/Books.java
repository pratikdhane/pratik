package com.example.author.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="books_info")
public class Books {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String title;
	int  pYear;
	
	@ManyToOne
	@JoinColumn(name="aid")
	@JsonBackReference
	Author author;
	
	public Books() {
		super();
	}
	public Books(int id, String title, int pYear) {
		super();
		this.id = id;
		this.title = title;
		this.pYear = pYear;
	}
	public int getId() {
		return id;
	}
	public String getTitle() {
		return title;
	}
	public int getpYear() {
		return pYear;
	}
	public Author getAuthor() {
		return author;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setpYear(int pYear) {
		this.pYear = pYear;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	
	

}
