package com.example.author.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.author.entity.Author;
import com.example.author.service.MyService;
//import com.example.oneToMany.entity.Trainer;
//import com.example.liabrary.entity.Liabrary;

@RestController
public class MyController1 {
	@Autowired
	MyService service;
	@PostMapping("/save")
	public String saveTrainer(@RequestBody Author a)
	{
	 return service.saveTrainer(a);
	 
	}
	@GetMapping("/findall")
	public List<Author>findAll()
	{
	  return service.findAll();
	}
	@GetMapping("/find/{id}")
	public Author findById(@PathVariable("id")int id)
	{
	  return service.findById(id);	
	}
	@PutMapping("/update/{id}")
	public String update(@PathVariable("id")int id,@RequestBody Author a)
	{
	  return service.update(id, a);	
	}
			}
